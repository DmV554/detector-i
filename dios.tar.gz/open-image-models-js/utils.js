/**
 * @fileoverview Common utilities.
 * Equivalent to open_image_models/utils.py
 */

// Node.js specific imports - these will cause errors in a browser environment
// Use conditional imports or environment checks if targeting both.
// For simplicity here, we assume Node.js for fs operations.
import fs from 'fs/promises';
import path from 'path';

// Performance API - available globally in modern Node.js (>=16) and browsers
// If targeting older Node.js, might need: const { performance } = require('perf_hooks');
// Let's assume modern environment or polyfill elsewhere.
const performance = globalThis.performance;

/**
 * A utility to time an asynchronous code block and log the result.
 * Similar to Python's context manager `log_time_taken`.
 *
 * @param {string} processName - Name of the process being timed.
 * @param {() => Promise<any>} asyncBlock - An async function containing the code to time.
 * @returns {Promise<any>} The result returned by the asyncBlock.
 */
export async function logTimeTaken(processName, asyncBlock) {
    const timeStart = performance.now();
    let result;
    try {
        result = await asyncBlock();
    } finally {
        const timeEnd = performance.now();
        const timeElapsed = timeEnd - timeStart;
        // Using console.info as a basic logger
        console.info(`Computation time of '${processName}' = ${timeElapsed.toFixed(3)}ms`);
    }
    return result;
}

/**
 * Measures the execution time of an asynchronous block.
 * Similar purpose to Python's `measure_time` context manager.
 *
 * @param {() => Promise<any>} asyncBlock - An async function containing the code to measure.
 * @returns {Promise<{ result: any, durationMs: number }>} An object containing the result
 * of the block and the execution duration in milliseconds.
 */
export async function measureTimeAsync(asyncBlock) {
    const start = performance.now();
    let result;
    let durationMs;
    try {
      result = await asyncBlock();
    } finally {
      const end = performance.now();
      durationMs = end - start;
    }
    return { result, durationMs };
}

/**
 * Measures the execution time of a synchronous block.
 *
 * @param {() => any} syncBlock - A synchronous function containing the code to measure.
 * @returns {{ result: any, durationMs: number }} An object containing the result
 * of the block and the execution duration in milliseconds.
 */
export function measureTimeSync(syncBlock) {
    const start = performance.now();
    let result;
    let durationMs;
    try {
        result = syncBlock();
    } finally {
        const end = performance.now();
        durationMs = end - start;
    }
    return { result, durationMs };
}


/**
 * **[Node.js only]** Context manager simulation for safe file writing.
 * Opens the specified file for writing, yields a file handle, and ensures
 * the file is removed if an exception occurs during the operation.
 *
 * Mimics Python's `safe_write` using fs.promises.open.
 *
 * Usage:
 * ```javascript
 * await safeWrite('./temp_file.txt', async (fileHandle) => {
 * await fileHandle.write('Hello safely!');
 * });
 * ```
 *
 * @param {string | URL} filePath - The path to the file to write.
 * @param {(fileHandle: fs.FileHandle) => Promise<void>} asyncWriterBlock - An async function that receives the file handle
 * and performs write operations.
 * @param {string | Buffer | null} [encoding=null] - Optional encoding (e.g., 'utf8'). If null, uses buffer mode.
 * Note: Node fs.open flags determine mode (write, binary etc.), not separate mode string like Python. 'w' is default.
 * @param {number | string} [mode=0o666] - File mode (permissions). Default is read/write for owner/group/others.
 * @returns {Promise<void>} A promise that resolves when the block completes successfully or rejects if an error occurs.
 */
export async function safeWrite(filePath, asyncWriterBlock, encoding = null, mode = 0o666) {
    let fileHandle;
    // Ensure filePath is a string for path.resolve if it's a URL object
    const resolvedPath = typeof filePath === 'string' ? path.resolve(filePath) : filePath;
    let errorOccurred = false;

    try {
        // fs.open with 'w' flag truncates or creates the file for writing.
        fileHandle = await fs.open(resolvedPath, 'w', mode);

        // Execute the user's writing logic with the handle
        await asyncWriterBlock(fileHandle);

    } catch (e) {
        errorOccurred = true;
        // Attempt to remove the file if an error occurred during writing block
        if (fileHandle) {
             // Ensure handle is closed before unlinking
             await fileHandle.close().catch(closeErr => console.error(`Error closing file during safeWrite cleanup: ${closeErr.message}`));
        }
        try {
            await fs.unlink(resolvedPath);
            console.warn(`safeWrite: Removed partially written file '${resolvedPath}' due to error.`);
        } catch (unlinkError) {
            // Ignore error if file doesn't exist (missing_ok=True equivalent)
            // or if other unlink error occurs (log it).
            if (unlinkError.code !== 'ENOENT') {
                console.error(`safeWrite: Error removing file '${resolvedPath}' during cleanup: ${unlinkError.message}`);
            }
        }
        // Re-throw the original error
        throw e;

    } finally {
        // Always ensure the file handle is closed if it was opened, unless an error already occurred during close
        if (fileHandle && !errorOccurred) { // Avoid double-closing if closed in catch
             await fileHandle.close().catch(closeErr => console.error(`Error closing file in safeWrite finally block: ${closeErr.message}`));
        }
    }
}


/**
 * Placeholder function to set seed for random number generators.
 * **NOTE:** This function DOES NOT seed JavaScript's built-in `Math.random()`.
 * Reproducibility requires using a library that supports seeded RNGs (e.g., 'seedrandom').
 * This function is provided for structural equivalence to the Python version.
 * You might integrate calls to specific library seeding functions here if needed.
 *
 * @param {number} [seed=7331] - An integer seed value.
 */
export function setSeed(seed = 7331) {
    console.warn(`setSeed(${seed}) called. NOTE: This does NOT seed Math.random(). Use a dedicated seeded RNG library for reproducibility.`);
    // Placeholder for potential integration with seeded libraries:
    // if (typeof someSeededRngLibrary !== 'undefined') {
    //   someSeededRngLibrary.seed(seed);
    // }
    // if (typeof tf !== 'undefined' && tf.setBackend) {
    //    // Example: TF.js might have backend-specific ways, but no global RNG seed.
    // }
}

// Example of a seeded RNG library usage (requires installing 'seedrandom')
/*
import seedrandom from 'seedrandom';

let globalRng = Math.random; // Default

export function setSeedWithSeedrandom(seed = 7331) {
    console.log(`Seeding RNG with seedrandom using seed: ${seed}`);
    globalRng = seedrandom(seed.toString()); // Replace Math.random with seeded version
}

export function getRandom() {
    return globalRng(); // Use the potentially seeded RNG
}
*/